$('#modalsAppend').append(`

<!--Login Modal start-->
<div class="modal fade" id="login" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content bg-dark">
            <div class="modal-header border-bottom-0">
                <h5 class="modal-title text-white">
                    <img src="./assets/images/logo-img.png" alt="logo image" />
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body border-bottom-0 text-white">
             
            </div>
        </div>
    </div>
</div>
<!--Login Modal end-->





`)